<html>
	<head>
		<title>Simple Form</title>
		<link rel="stylesheet" type="text/css" href="CSS/main.css" media="screen" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script type='text/javascript' src='common.js'></script>
	</head>
	<body>
		<h3>Survey Verification</h3>
		
	</body>
</html>