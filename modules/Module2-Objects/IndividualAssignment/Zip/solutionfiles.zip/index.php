<html>
	<head>
		<title>Individual Assignment Sample</title>
	</head>
	<body>
		<img src="linecountgraph.php" />
	</body>
</html>